"""
AthleteGuard AI Backend
-----------------------
FastAPI service for athlete readiness and risk assessment.

Current scope:
- ACWR calculation
- Sleep assessment
- HRV assessment
- Readiness score
- Risk level
- Recommendation
- Explainable top factors

Frontend is intentionally excluded.
"""

from __future__ import annotations

from typing import Literal

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field, field_validator


# ============================================================
# FastAPI Application
# ============================================================

app = FastAPI(
    title="AthleteGuard AI API",
    description=(
        "Backend API for athlete readiness and training-risk assessment."
    ),
    version="1.0.0",
)


# ============================================================
# Request / Response Models
# ============================================================

class ReadinessRequest(BaseModel):
    """Input data required for athlete readiness assessment."""

    player_id: int = Field(
        ...,
        ge=1,
        description="Unique athlete/player identifier.",
        examples=[101],
    )

    acute_load: float = Field(
        ...,
        gt=0,
        description="Recent/acute training load.",
        examples=[800.0],
    )

    chronic_load: float = Field(
        ...,
        gt=0,
        description="Longer-term/chronic training load.",
        examples=[600.0],
    )

    sleep_hours: float = Field(
        ...,
        ge=0,
        le=24,
        description="Average sleep duration in hours.",
        examples=[7.5],
    )

    hrv_status: Literal["low", "normal", "high"] = Field(
        default="normal",
        description="Current HRV status.",
        examples=["normal"],
    )

    @field_validator("hrv_status", mode="before")
    @classmethod
    def normalize_hrv_status(cls, value: str) -> str:
        """Normalize HRV input to lowercase and validate it."""

        if not isinstance(value, str):
            raise ValueError(
                "hrv_status must be a string."
            )

        normalized = value.strip().lower()

        allowed = {"low", "normal", "high"}

        if normalized not in allowed:
            raise ValueError(
                "hrv_status must be one of: low, normal, high."
            )

        return normalized


class ReadinessResponse(BaseModel):
    """Structured readiness assessment returned by the API."""

    player_id: int

    acwr_ratio: float

    readiness_score: int = Field(
        ...,
        ge=0,
        le=100,
    )

    risk_level: Literal[
        "High Risk",
        "Moderate Risk",
        "Optimal",
    ]

    risk_status: Literal[
        "High Risk",
        "Moderate Risk",
        "Optimal",
    ]

    recommendation: str

    top_factors: list[str]


class HealthResponse(BaseModel):
    """API health response."""

    status: str
    service: str
    version: str


# ============================================================
# Business Logic
# ============================================================

def calculate_acwr(
    acute_load: float,
    chronic_load: float,
) -> float:
    """
    Calculate Acute:Chronic Workload Ratio.

    ACWR = acute load / chronic load.
    """

    if chronic_load <= 0:
        raise ValueError(
            "Chronic load must be greater than zero."
        )

    return round(
        acute_load / chronic_load,
        2,
    )


def evaluate_athlete_status(
    acwr: float,
    sleep_hours: float,
    hrv_status: str,
) -> dict[str, object]:
    """
    Evaluate athlete readiness and risk.

    Current rules:

    High Risk:
        - ACWR > 1.5
        - OR sleep < 5 hours
        - OR HRV is low

    Moderate Risk:
        - 1.2 <= ACWR <= 1.5
        - OR 5.0 <= sleep < 6.5 hours

    Optimal:
        - all other cases

    A low ACWR (< 0.8) is retained as an explanatory
    factor but does not automatically increase the risk level.
    """

    factors: list[str] = []

    # --------------------------------------------------------
    # Workload factor
    # --------------------------------------------------------

    if acwr > 1.5:
        factors.append(
            f"High injury risk due to workload spike "
            f"(ACWR: {acwr})"
        )

    elif acwr < 0.8:
        factors.append(
            f"Low training load (ACWR: {acwr})"
        )

    # --------------------------------------------------------
    # Sleep factor
    # --------------------------------------------------------

    if sleep_hours < 6.0:
        factors.append(
            f"Insufficient sleep ({sleep_hours:.1f} hours)"
        )

    # --------------------------------------------------------
    # HRV factor
    # --------------------------------------------------------

    if hrv_status == "low":
        factors.append(
            "High physiological stress based on HRV"
        )

    # --------------------------------------------------------
    # Risk rules
    # --------------------------------------------------------

    high_risk = (
        acwr > 1.5
        or sleep_hours < 5.0
        or hrv_status == "low"
    )

    moderate_risk = (
        1.2 <= acwr <= 1.5
        or 5.0 <= sleep_hours < 6.5
    )

    # --------------------------------------------------------
    # HIGH RISK
    # --------------------------------------------------------

    if high_risk:
        return {
            "score": 42,
            "level": "High Risk",
            "status": "High Risk",
            "recommendation": (
                "Reduce training load by 50% "
                "and prioritize recovery."
            ),
            "factors": (
                factors
                if factors
                else ["High stress indicators"]
            ),
        }

    # --------------------------------------------------------
    # MODERATE RISK
    # --------------------------------------------------------

    if moderate_risk:
        return {
            "score": 68,
            "level": "Moderate Risk",
            "status": "Moderate Risk",
            "recommendation": (
                "Reduce training load by 20% "
                "and monitor recovery indicators."
            ),
            "factors": (
                factors
                if factors
                else ["Moderate stress indicators"]
            ),
        }

    # --------------------------------------------------------
    # OPTIMAL
    # --------------------------------------------------------

    return {
        "score": 92,
        "level": "Optimal",
        "status": "Optimal",
        "recommendation": (
            "Maintain the standard training program "
            "while continuing routine monitoring."
        ),
        "factors": (
            factors
            if factors
            else [
                "All monitored metrics are currently "
                "within the configured optimal range."
            ]
        ),
    }


# ============================================================
# API Endpoints
# ============================================================

@app.get(
    "/",
    response_model=HealthResponse,
    tags=["Health"],
)
def root() -> HealthResponse:
    """Basic API health check."""

    return HealthResponse(
        status="ok",
        service="AthleteGuard AI API",
        version=app.version,
    )


@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["Health"],
)
def health_check() -> HealthResponse:
    """Dedicated health endpoint for monitoring."""

    return HealthResponse(
        status="healthy",
        service="AthleteGuard AI API",
        version=app.version,
    )


@app.post(
    "/get_player_readiness",
    response_model=ReadinessResponse,
    status_code=status.HTTP_200_OK,
    tags=["Readiness"],
)
def get_player_readiness(
    data: ReadinessRequest,
) -> ReadinessResponse:
    """Calculate athlete readiness and risk assessment."""

    try:
        acwr = calculate_acwr(
            acute_load=data.acute_load,
            chronic_load=data.chronic_load,
        )

        metrics = evaluate_athlete_status(
            acwr=acwr,
            sleep_hours=data.sleep_hours,
            hrv_status=data.hrv_status,
        )

        return ReadinessResponse(
            player_id=data.player_id,
            acwr_ratio=acwr,
            readiness_score=int(
                metrics["score"]
            ),
            risk_level=str(
                metrics["level"]
            ),
            risk_status=str(
                metrics["status"]
            ),
            recommendation=str(
                metrics["recommendation"]
            ),
            top_factors=list(
                metrics["factors"]
            ),
        )

    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc